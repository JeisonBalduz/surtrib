<?php 
//Incluímos inicialmente la conexión a la base de datos
require "../config/Conexion.php";

Class Contrih
{
	//Implementamos nuestro constructor
	public function __construct()
	{
		
	}
	//Implementamos un método para insertar registros
	public function insertar($licencia,$tiponac,$cedularif,$razsocial,$correo,$tlf,$codcel,$celular,$modo,$estado_pk,$municipio_pk,
	                         $parroquia_pk,$ciudad_pk,$sector,$calle,$edificio,$numeroedif,$medit,$representative,$addresses,$code,$registrado,
							 $conformidaduso,$tieneinmueble,$taseo,$texpe,$tapu,$tilico,$pkenumerator,$contrato,$viejo,$ultima_declaracion)
	{
		$sql="INSERT INTO contrihacienda (licencia,tiponac,cedularif,razsocial,correo,tlf,codcel,celular,modo,estado_pk,municipio_pk,
		                           parroquia_pk,ciudad_pk,sector,calle,edificio,numeroedif,medit,representative,addresses,code,registrado,
		                           conformidaduso,tieneinmueble,taseo,texpe,tapu,tilico,pkenumerator,contrato,viejo,ultima_declaracion,estatus)
		VALUES ('$licencia','$tiponac','$cedularif','$razsocial','$correo','$tlf','$codcel','$celular','$modo','$estado_pk','$municipio_pk',
		                           '$parroquia_pk','$ciudad_pk','$sector','$calle','$edificio','$numeroedif','$medit','$representative','$addresses','$code','$registrado',
                                   '$conformidaduso','$tieneinmueble','$taseo','$texpe','$tapu','$tilico','$pkenumerator','$contrato','$viejo','$ultima_declaracion','A')";
		return ejecutarConsulta($sql);
	}
   
	//Implementamos un método para editar registros
	public function editar($rfc,$licencia,$tiponac,$cedularif,$razsocial,$correo,$tlf,$codcel,$celular,$modo,$estado_pk,$municipio_pk,
	                         $parroquia_pk,$ciudad_pk,$sector,$calle,$edificio,$numeroedif,$medit,$representative,$addresses,$code,$registrado,
							 $conformidaduso,$tieneinmueble,$taseo,$texpe,$tapu,$tilico,$pkenumerator,$contrato,$viejo,$ultima_declaracion)
	{
		$sql="UPDATE contrihacienda SET 
								   licencia='$licencia',
								   tiponac='$tiponac',
								   cedularif='$cedularif', 
								   razsocial='$razsocial',
								   correo='$correo',
								   tlf='$tlf',
								   codcel='$codcel', 
								   celular='$celular',
								   modo='$modo',
								   estado_pk='$estado_pk',
								   municipio_pk='$municipio_pk',
								   parroquia_pk='$parroquia_pk',
								   ciudad_pk='$ciudad_pk',
								   sector='$sector',
								   calle='$calle',
								   edificio='$edificio', 
								   numeroedif='$numeroedif',
								   medit='$medit',
								   representative='$representative',
								   addresses='$addresses', 
								   code='$code',
								   registrado='$registrado',
								   conformidaduso='$conformidaduso',
								   tieneinmueble='$tieneinmueble',
								   taseo='$taseo',
								   texpe='$texpe',
								   tapu='$tapu',
								   tilico='$tilico',
								   pkenumerator='$pkenumerator', 
								   contrato='$contrato',
								   viejo='$viejo',
								   ultima_declaracion='$ultima_declaracion'
								   
								   WHERE rfc='$rfc'";
		return ejecutarConsulta($sql);
	}
	//Implementamos un método para desactivar Clientes
	public function desactivar($rfc)
	{
		$sql="UPDATE contrihacienda SET estatus ='D' WHERE rfc='$rfc'";
		return ejecutarConsulta($sql);
	}
    //Implementamos un método para Activar Clientes
	public function activar($rfc)
	{
		$sql="UPDATE contrihacienda SET estatus ='A' WHERE rfc='$rfc'";
		return ejecutarConsulta($sql);
	}
	//Implementar un método para mostrar los datos de un registro a modificar
	public function mostrar($rfc)
	{
		$sql="SELECT * FROM contrihacienda WHERE rfc='$rfc'";
		return ejecutarConsultaSimpleFila($sql);
	}

	public function mostrarliq($tramite)
	{
		$sql="SELECT m.tramite AS tram,m.idt AS idtipotramite,t.detalle AS detalle, m.totpag AS monton FROM mayorhacienda m INNER JOIN taxhacienda t ON m.idt=t.idt WHERE m.tramite='$tramite'";
		return ejecutarConsultaSimpleFila($sql);
	}

	public function mostrartotal($rfc)
	{
		$sql="SELECT SUM(m.totliq) AS stotaliq,SUM(m.deferred) AS sdiferido,SUM(m.descuento) AS sdescuento,SUM(m.totpag) AS stotalp,(SUM(m.totliq)-SUM(m.deferred)-SUM(m.descuento)-SUM(m.totpag)) AS stotaltotal FROM mayorhacienda m INNER JOIN 
		taxhacienda t ON m.idt=t.idt INNER JOIN contrihacienda c ON m.idrfc=c.rfc WHERE m.idrfc='$rfc'";
		return ejecutarConsultaSimpleFila($sql);
	}

	//Implementar un método para listar los registros
	public function listar()
	{
		$sql="SELECT a.*,p.*,f.fpago FROM contrihacienda a LEFT JOIN activecocontri c ON a.rfc=c.rfc INNER JOIN activecot p ON c.actividad=p.id LEFT JOIN (SELECT DATE_FORMAT(MAX(m.fpagado), '%d/%m/%y') AS fpago, m.idrfc AS rfcus FROM mayorhacienda m INNER JOIN contrihacienda us ON m.idrfc=us.rfc WHERE m.idt=1024 GROUP BY m.idrfc) AS f ON a.rfc=f.rfcus";
		return ejecutarConsulta($sql);		
	}

	public function listar2($comodinbusqueda)
	{
		$sql="SELECT a.*,p.*,f.fpago FROM contrihacienda a LEFT JOIN activecocontri c ON a.rfc=c.rfc INNER JOIN activecot p ON c.actividad=p.id LEFT JOIN (SELECT DATE_FORMAT(MAX(m.fpagado), '%d/%m/%y') AS fpago, m.idrfc AS rfcus FROM mayorhacienda m INNER JOIN contrihacienda us ON m.idrfc=us.rfc WHERE m.idt=1024 GROUP BY m.idrfc) AS f ON a.rfc=f.rfcus WHERE a.rfc='$comodinbusqueda'";
		return ejecutarConsulta($sql);		
	}
	public function select()
	{
		$sql="SELECT * FROM contrihacienda";
		return ejecutarConsulta($sql);		
	}

	public function estadocuenta($comodinbusqueda)
	{
		$sql="SELECT m.moment AS fecha,m.tramite AS tramite,m.idt AS idtributo,t.detalle AS tributo,m.totliq AS totaliq,m.deferred AS diferido,m.descuento AS descuento,m.totpag AS totalp,(m.totliq-m.deferred-m.descuento-m.totpag) AS totaltotal FROM mayorhacienda m INNER JOIN taxhacienda t ON m.idt=t.idt INNER JOIN 
		contrihacienda c ON m.idrfc=c.rfc WHERE m.idrfc='$comodinbusqueda'";
		return ejecutarConsulta($sql);		
	}



}
?>