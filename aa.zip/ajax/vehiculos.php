<?php 
session_start(); 
require_once "../modelos/Vehiculos.php";

$vehiculo=new Vehiculo();

$rfc=$_SESSION['rfc'];
$iduser=$_SESSION['idusuario'];


$id=isset($_POST["id"])? limpiarCadena($_POST["id"]):"";
$idv=isset($_POST["idv"])? limpiarCadena($_POST["idv"]):"";
$registered=isset($_POST["registered"])? limpiarCadena($_POST["registered"]):"";
$idtvehiculo=isset($_POST["idtvehiculo"])? limpiarCadena($_POST["idtvehiculo"]):"";
$licenseplate=isset($_POST["licenseplate"])? limpiarCadena($_POST["licenseplate"]):"";
$serialmotor=isset($_POST["serialmotor"])? limpiarCadena($_POST["coserialmotorrreo"]):"";
$serialcarro=isset($_POST["serialcarro"])? limpiarCadena($_POST["serialcarro"]):"";
$marca=isset($_POST["marca"])? limpiarCadena($_POST["marca"]):"";
$modelos=isset($_POST["modelos"])? limpiarCadena($_POST["modelos"]):"";
$puestos=isset($_POST["puestos"])? limpiarCadena($_POST["puestos"]):"";
$pesos=isset($_POST["pesos"])? limpiarCadena($_POST["pesos"]):"";
$anio=isset($_POST["anio"])? limpiarCadena($_POST["anio"]):"";
$fechacompra=isset($_POST["fechacompra"])? limpiarCadena($_POST["fechacompra"]):"";
$cpropietary=isset($_POST["cpropietary"])? limpiarCadena($_POST["cpropietary"]):"";
$estado=isset($_POST["estado"])? limpiarCadena($_POST["estado"]):"";
$tiponac=isset($_POST["tiponac"])? limpiarCadena($_POST["tiponac"]):"";
$cedularif=isset($_POST["cedularif"])? limpiarCadena($_POST["cedularif"]):"";
$fpago=isset($_POST["fpago"])? limpiarCadena($_POST["fpago"]):"";
$detalle=isset($_POST["detalle"])? limpiarCadena($_POST["detalle"]):"";
$idt=isset($_POST["idt"])? limpiarCadena($_POST["idt"]):"";
$detalles=isset($_POST["detalles"])? limpiarCadena($_POST["detalles"]):"";

$rfc2=isset($_POST["rfc2"])? limpiarCadena($_POST["rfc2"]):"";
$ruf2=isset($_POST["ruf2"])? limpiarCadena($_POST["ruf2"]):"";
$idusuario2=isset($_POST["idusuario2"])? limpiarCadena($_POST["idusuario2"]):"";
switch ($_GET["op"]){
        
	case 'guardaryeditar':
		if (empty($id)){
			$rspta=$vehiculo->insertar($idtvehiculo,$rfc,$licenseplate,$serialmotor,$serialcarro,$marca,$modelos,$puestos,$pesos,$anio,$fechacompra);
			echo $rspta ? "Vehiculo registrado" : "Vehiculo no se pudo registrar";
		}
		else {
			$rspta=$vehiculo->editar($id,$registered,$idtvehiculo,$licenseplate,$marca,$modelos,$puestos,$pesos,$anio,$fechacompra);
			echo $rspta ? "Vehiculo actualizado" : "Vehiculo no se pudo actualizar";
		}
	break;


	case 'guardaryeditar2':
		if (empty($id)){
			$rspta=$vehiculo->insertar2($idtvehiculo,$ruf2,$licenseplate,$serialmotor,$serialcarro,$marca,$modelos,$puestos,$pesos,$anio,$fechacompra);
			echo $rspta ? "Vehiculo registrado" : "Vehiculo no se pudo registrar";
		}
		else {
			$rspta=$vehiculo->editarRegistrosAdmin($id,$ruf2,$registered,$idtvehiculo,$licenseplate,$marca,$modelos,$puestos,$pesos,$anio,$fechacompra);
			echo $rspta ? "Vehiculo actualizado" : "Vehiculo no se pudo actualizar";
		}
	break;

	case 'insertartramitemv':
		$rspta=$vehiculo->insertartramitemv($rfc2,$idtvehiculo,$idv,$idusuario2);
 		echo $rspta ? "Vehiculo Declarado" : "Vehiculo no pudo ser declarado";
	break;

	case 'desactivar':
		$rspta=$vehiculo->desactivar($id);
 		echo $rspta ? "Contribuyente desactivado" : "Contribuyente no se pudo desactivar";
	break;

	case 'activar':
		$rspta=$vehiculo->activar($id);
 		echo $rspta ? "Contribuyente activado" : "Contribuyente no se pudo activar";
	break;
        
	case 'mostrar':
		$rspta=$vehiculo->mostrar($id);
 		//Codificar el resultado utilizando json
 		echo json_encode($rspta);
	break;

	case 'mostrartaxveh':
		$rspta = $vehiculo->mostrartaxveh();
		while ($reg = $rspta->fetch_object())
        {
            echo '<option value=' . $reg->idt. '>' . $reg->idt. '-' . $reg->detalle. '</option>';
			
        }
	break;

	case 'listarcon':

		$rspta=$vehiculo->listarcon($rfc);
 		//Vamos a declarar un array
 		$data= Array();
 		
 		$timestampActual = time();
		$añoActual = date('Y', $timestampActual);

 		while ($reg=$rspta->fetch_object()){

			if ($reg->tramite==NULL){
				$opcion='<a target="_blank" href="../reportesPDF/tramitevehiculo.php?codigo='.$reg->tramite.'");" class="btn btn-info">Ver Registro</a>';
			}
			else {
				$opcion='<a target="_blank" href="../reportesPDF/tramitevehiculo.php?codigo='.$reg->tramite.'");" class="btn btn-info">Ver Registro</a>';
			}

			if ($reg->period==NULL){
				$periodo='<span class="badge bg-danger">Vehiculo por Declarar</span>';
			}
			else  if ($reg->period==$añoActual AND $reg->mcondition=='L'){
				$periodo='<span class="badge bg-danger">Tramite por Conciliar</span>';
			}
			
				else  if ($reg->mcondition=='L'){
				$opcion2='<span class="badge bg-danger">Tramite por Pagar</span>';
			}
			
			else  if ($reg->mcondition=='D'){
				$opcion2='<span class="badge bg-danger">Tramite por Conciliar</span>';
			}
			else  if ($reg->period==$añoActual AND $reg->mcondition=='P') {
				$opcion2='<span class="badge bg-info">Solven 2024</span>';
			}
			
			else {
				$periodo=$reg->period;
			}

			if ($reg->mcondition==NULL){
				$opcion2='<button type="button" class="btn btn-info" data-toggle="modal" data-target="#formulario2" onclick="declararvehiculo('.$reg->id.')">Declarar</button>';
			}
			
			if ($reg->period ==$añoActual AND $reg->mcondition=='P'){
			    	$opcion2='<button type="button" class="btn btn-secondary">Declarar</button>';
			   
			} 
			else  if ($reg->period!=$añoActual){
				$opcion2='<button type="button" class="btn btn-info" data-toggle="modal" data-target="#formulario2" onclick="declararvehiculo('.$reg->id.')">Declarar</button>';
			}
			
			
		

			
 				$data[]=[
				"0"=>$opcion,
				"1"=>$reg->licenseplate,
				"2"=>$reg->marca,
				"3"=>$reg->modelos,
				 "4"=>$reg->anio,
				"5"=>$reg->fregistro,
				"6"=>$periodo,
				"7"=>$opcion2,
				"8"=>$reg->detalle,

 				];
 		}

	
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
	



	case 'listar':

		$rspta=$vehiculo->listar();
 		//Vamos a declarar un array
 		$data= Array();

		$timestampActual = time();
		$añoActual = date('Y', $timestampActual);

 		while ($reg=$rspta->fetch_object()){
			if ($reg->periodo==NULL OR $reg->periodo == $añoActual){
				//$opcion2='<button type="button" class="btn btn-secondary">Declarar</button>';
			}
			else {
				//$opcion2='<button type="button" class="btn btn-info" data-toggle="modal" data-target="#formulario2" onclick="declararvehiculo('.$reg->id.')">Declarar</button>';
			}
	
 			$data[]=[
 				"0"=>'<button class="btn btn-info" onclick="mostrar('.$reg->id.')"><i class="fa fa-user"></i></button>',
				"1"=>$reg->razsocial,
				"2"=>$reg->tiponac."".$reg->cedularif,
 				"3"=>$reg->marca,
				"4"=>$reg->modelos,
 				"5"=>$reg->puestos,
 				"6"=>$reg->rfc,
			    "7"=>$reg->licenseplate,
				"8"=>$reg->detalle
			//	"9"=>$opcion2,
				
				
 				
 				];

 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;

	case 'listar2':

		$rspta=$contrih->listar2($comodinbusqueda);
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
 			$data[]=[
				"0"=>($reg->estado)?'<button class="btn btn-info" onclick="mostrar('.$reg->id.')"><i class="fa fa-user"></i></button>'.
				' <button class="btn btn-danger" onclick="desactivar('.$reg->id.')"><i class="fa fa-edit"></i></button>':
				'<button class="btn btn-info" onclick="mostrar('.$reg->id.')"><i class="fa fa-pencil"></i></button>'.
				' <button class="btn btn-primary" onclick="activar('.$reg->id.')"><i class="fa fa-edit"></i></button>',
			   "1"=>$reg->tiponac."-".$reg->cedularif,
				"2"=>$reg->marca,
			   "3"=>$reg->modelos,
				"4"=>$reg->puestos,
				"5"=>$reg->pesos,
			   "6"=>$reg->fechacompra,
			   "7"=>$reg->detalle,
			   "8"=>$reg->fpago
 				
 				];

 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
   case 'consultarplaca':
        
        $rspta=$vehiculo->consultarplaca($licenseplate);
        $reg=$rspta->fetch_object();
         if($reg){
           echo json_encode(array("placa"=>1));
        }
        else
        	echo json_encode(array("placa"=>0));

   break;
   case 'cargarmarca':
		$rspta = $vehiculo->getmacas();
		while ($reg = $rspta->fetch_object())
        {
            echo '<option value="'. $reg->marca.'">' . $reg->marca. '</option>';
			
        }
	break;
	
	case 'buscarRegistro':

					
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {

			// Obtenemos los datos del formulario
			$buscar = $_POST['ruf'];
		
			$valores = array();
			$valores['existe'] = "0";
			
			// Realizamos la consulta a la base de datos
			$rspta=$vehiculo->buscarUsuario($buscar);
			while($consulta = mysqli_fetch_array($rspta))
			{
				$valores['existe'] = "1";
					$valores['name'] = $consulta['name'];
					$valores['rif'] = $consulta['rif'];
			}
			sleep(1);
				$valores = json_encode($valores);
				echo $valores;
		
		} else {
		
			// La petición no es POST
			echo "La petición no es POST";
		
		}

		
    break;
	

}
?>