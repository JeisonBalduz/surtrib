# reportesFPDF
👾 Este será el repositorio en donde estaré actualizando el curso de FPDF de mi canal de Youtube

_Actualmente se encuentran 3 plantillas, con todo lo que necesitas para empezar a crear tus reportes!_

## Pasos 🚀
* 1. Crea una carpeta en htdocs
* 2. Descarga o copia el codigo de este reporsitorio
* 3. Para probar las plantillas necesitas enceder Apache
* 4. Ahora en un navegador podes poner en la URL, el nombre de la carpeta / el nombre del reporte.php

_También puedes guiarte de el video en youtube o puedes seguir los pasos que te dejo a continuación._
Puedes ir a  **Youtube** en donde aparezco como Kodo Sensei.


### Pre-requisitos 📋

_Necesitas tener instalodo XAMMP con una versión PHP > 5 _

## Si deeas más plantilas ⚙️

Podes escribir en los comentarios y yo con gusto haré más ejemplos con todo lo que necesites !!

### Agradecimientos 🤖✌

Gracias por llegar hasta aquí significa que te gusto el tutorial!! Porfavor Suscribete a mi canal para más contenido como este !

---
⌨️ con ❤️ por [Kodo Sensei](https://github.com/kodosensei) 😊


