# Previsualización de imágenes al cargarlas
