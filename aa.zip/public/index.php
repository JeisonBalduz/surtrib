<?php
  header("Location: ../vistas/conceptocontribuyente.php");
?>