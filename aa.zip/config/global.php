<?php 
//Ip de la pc servidor de base de datos
define("DB_HOST","localhost");

//Nombre de la base de datos alcald14_surtri122
define("DB_NAME", "surtribc_2024");

//Usuario de la base de datos alcald14_lizkarlo
define("DB_USERNAME", "surtribc_root");

//Contraseña del usuario de la base de datos
define("DB_PASSWORD", "Ifaoriire.2102");

//definimos la codificación de los caracteres
define("DB_ENCODE","utf8");

//Definimos una constante como nombre del proyecto
define("PRO_NOMBRE","");
?>