<?php
  header("Location: conceptocontribuyente.php");
?>