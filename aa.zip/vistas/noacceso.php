
<!--Contenido-->
      <!-- Content Wrapper. Contains page content -->
      
      <section class="content">
      <br>
      <br>
      <br>
      <br>
      <div class="error-page">
        <h2 class="headline text-danger">Sin Acceso</h2>

          <form class="search-form">
            <div class="input-group">
            <h3><i class="fas fa-exclamation-triangle text-danger"></i> No tiene acceso a esta parte del Sistema</h3>

<p>
  Si presenta algun inconveniente salga y reingrese al sistema.
  <a href="../ajax/usuarios.php?op=salir">Salir del sistema</a>
</p>
            </div>
            <!-- /.input-group -->
          </form>
        </div>
      </div>
      <!-- /.error-page -->

    </section>

    </div><!-- /.content-wrapper -->
  <!--Fin-Contenido-->